-- Survivor UI - Copyright (C) 2026 morderous - GPL-3.0 - github.com/morderous/survivor-ui
-- Survivor UI: the build, in the right column between the run tracker and the
-- damage meter, the same spells side by side with what they deal.
--
-- Every spell slot, filled or not: each spell with its icon, its name in the
-- same color the damage meter gives it, its rank, and its range, its cooldown
-- or both (as chosen: Build list tab), then the racial apart (it takes no
-- slot). The third column, Info, holds what matters most besides the
-- cooldown: a range, a radius, how long a spell lasts (its row a timer while
-- it is up), or how much a heal gives back. Empty slots show, since how many
-- are left matters at every card choice. Hover a spell for its card: rank,
-- cooldown, damage and crits. The spells run from the highest rank down, each
-- in a border of its color.
--
-- The jewelry worn (neck, rings, trinkets), the gear a run drops, is a panel of
-- its own, under the list until moved, with its own switch and tab (Jewelry
-- worn): each slot filled with the piece's quality color, with what it gives
-- in short, read off its tooltip ("Neck  CDR · DMG"), or the piece's name.
--
-- From the game's addon API (AZS_SPELLS); without it nothing shows. Hold Alt
-- and drag to move; /sui build hides it.

if SurvivorUI_Standby then return end

local FLAT = "Interface\\ChatFrame\\ChatFrameBackground"
local ART = "Interface\\AddOns\\SurvivorUI\\Art\\"
local FONT_BUMP = SurvivorUI_FONT_BUMP or 0

local WIDTH = 224
local ROW_HEIGHT = 18
local TITLE_HEIGHT = 20
local HEAD_HEIGHT = 13          -- the columns' names, under the title
local SLOTS = 6                 -- spell slots a run has
local RACIAL_SLOT = 12          -- the action bar's last button carries the racial
local MUTED = { 0.45, 0.45, 0.45 }
local GEAR_SLOTS = {               -- inventory slot, label
	{ 2, "Neck" }, { 11, "Ring" }, { 12, "Ring" }, { 13, "Trinket" }, { 14, "Trinket" },
}
local LIST_HEIGHT = TITLE_HEIGHT + HEAD_HEIGHT + (SLOTS + 1) * ROW_HEIGHT + 6

local function Settings()
	SurvivorUIDB = SurvivorUIDB or {}
	if SurvivorUIDB.buildList == nil then
		SurvivorUIDB.buildList = true
	end
	return SurvivorUIDB
end

-- No backgrounds (the options' No backgrounds, Experimental): this window's
-- ground away, with the switch on and the window not kept ("build", "worn").
local function Bare(key)
	local db = SurvivorUIDB
	return db and db.noBackgrounds and not (db.noBackgroundsOff and db.noBackgroundsOff[key]) or false
end

local function Field(entry, name, index)
	if entry[name] ~= nil then
		return entry[name]
	end
	return entry[index]
end

-- The action button of the spell at this index of the game's list (Meter.lua,
-- SurvivorUI_SpellSlot: the list's order, unless a spell was dragged
-- elsewhere), for its icon and its tooltip.
local function Slot(index, count)
	if SurvivorUI_SpellSlot then
		return SurvivorUI_SpellSlot(index)
	end
	return index == count and RACIAL_SLOT or index
end

-- "holy_wrath" as the meter and the cards name it: "Holy Wrath". The game
-- spells soul_fire "Soulfire" (its 0.110), as the meter does (Meter.lua).
local NAMES = {
	sw_pain = "Shadow Word: Pain", pw_shield = "Power Word: Shield",
	demo_shout = "Demoralizing Shout", hunters_mark = "Hunter's Mark",
	soul_fire = "Soulfire", rockbiter = "Rockbiter Weapon",
}

-- "of", "the" and "and" small after the first word, as the meter has them:
-- "Call of Flame". The colors go by the name, so the spelling must match.
local LOWER_WORDS = { of = true, the = true, ["and"] = true }

local function SpellName(key)
	if NAMES[key] then
		return NAMES[key]
	end
	local name = string.gsub(key or "?", "_", " ")
	local first = true
	return (string.gsub(name, "(%a)([%w']*)", function(initial, rest)
		local word = initial..rest
		if not first and LOWER_WORDS[string.lower(word)] then
			return string.lower(word)
		end
		first = false
		return string.upper(initial)..rest
	end))
end
-- For the hourglass's tooltip (FloorHourglass.lua).
SurvivorUI_SpellKeyName = SpellName

local function Running()
	if not (AZS_GetPhase and AZS_SPELLS) then
		return false
	end
	local phase = AZS_GetPhase()
	return phase and phase ~= "ready"
end

------------------------------------------------------------------------------
-- The frame.

local list = CreateFrame("Frame", "SurvivorUIBuild", UIParent)
list:SetWidth(WIDTH + 12)
list:SetHeight(LIST_HEIGHT)
list:SetPoint("TOPRIGHT", UIParent, "TOPRIGHT", -12, -260)
list:SetBackdrop({ bgFile = FLAT })
list:SetBackdropColor(0.04, 0.04, 0.07, 0.55)
list:SetMovable(true)
list:Hide()

local function SavePlace()
	local settings = Settings()
	settings.buildLeft = math.floor(list:GetLeft() + 0.5)
	settings.buildTop = math.floor(list:GetTop() + 0.5)
end

local function RestorePlace()
	local settings = Settings()
	list:ClearAllPoints()
	if settings.buildLeft then
		list:SetPoint("TOPLEFT", UIParent, "BOTTOMLEFT", settings.buildLeft, settings.buildTop)
	elseif SurvivorUITracker then
		-- Under the run tracker, right edges together.
		list:SetPoint("TOPRIGHT", SurvivorUITracker, "BOTTOMRIGHT", 8, -14)
	else
		list:SetPoint("TOPRIGHT", UIParent, "TOPRIGHT", -12, -260)
	end
end

list.title = list:CreateFontString(nil, "OVERLAY")
list.title:SetFont(SurvivorUI_FONT, 11 + FONT_BUMP, "OUTLINE")
list.title:SetPoint("TOPLEFT", list, "TOPLEFT", 7, -6)
list.title:SetTextColor(1, 0.82, 0)
list.title:SetText(SurvivorUI_T("Build"))

list.count = list:CreateFontString(nil, "OVERLAY")
list.count:SetFont(SurvivorUI_FONT, 10 + FONT_BUMP, "OUTLINE")
list.count:SetPoint("TOPRIGHT", list, "TOPRIGHT", -7, -7)

------------------------------------------------------------------------------
-- The columns at the right of each spell: its range and its cooldown (each
-- as chosen: Build list tab) and its rank, each under its name in the header
-- and between dividers. Laid out from the right edge; the name takes the
-- rest.

-- Info's symbol a column of its own at its left, no name over it.
local COLUMN_WIDTH = { rank = 24, cd = 30, range = 34, symbol = 13 }
local columns                   -- [key] = { right, width, divider }, the ones shown
local columnsKey
local nameRoom = WIDTH - ROW_HEIGHT - 70
-- The rank column's width: a number's, or as wide as the longest Roman
-- numeral shown needs (RankRoom, by Draw).
local rankWidth = COLUMN_WIDTH.rank

-- The columns for these choices (each on or off: Build list tab) and the
-- room left for the name; the options' preview lays its rows out by them too
-- (SurvivorUI_BuildLayout).
local function Layout(showRange, showCooldown, showSymbol, showRank, rankRoom)
	local laid = {}
	local order = {}
	if showRank then
		table.insert(order, "rank")
	end
	if showCooldown then
		table.insert(order, "cd")
	end
	if showRange then
		table.insert(order, "range")
		if showSymbol then
			table.insert(order, "symbol")
		end
	end
	local right = 2
	for index = 1, table.getn(order) do
		local key = order[index]
		local width = key == "rank" and (rankRoom or COLUMN_WIDTH.rank) or COLUMN_WIDTH[key]
		laid[key] = { right = right, width = width, divider = right + width + 1 }
		right = right + width + 3
	end
	return laid, WIDTH - right - ROW_HEIGHT - 1
end

local function Columns(showRange, showCooldown, showSymbol, showRank)
	local key = (showRange and "r" or "")..(showCooldown and "c" or "")..(showSymbol and "s" or "")..(showRank and rankWidth or "")
	if key == columnsKey then
		return false
	end
	columnsKey = key
	columns, nameRoom = Layout(showRange, showCooldown, showSymbol, showRank, rankWidth)
	return true
end

-- A column's text, centered in its column; away with its column.
local function PlaceText(text, column)
	text:ClearAllPoints()
	if column then
		text:SetPoint("RIGHT", text:GetParent(), "RIGHT", -column.right, 0)
		text:SetWidth(column.width)
		text:Show()
	else
		text:Hide()
	end
end

local head = CreateFrame("Frame", nil, list)
head:SetPoint("TOPLEFT", list, "TOPLEFT", 6, -TITLE_HEIGHT)
head:SetWidth(WIDTH)
head:SetHeight(HEAD_HEIGHT)
local function HeadLabel(text)
	local label = head:CreateFontString(nil, "OVERLAY")
	label:SetFont(SurvivorUI_FONT, 8 + FONT_BUMP, "OUTLINE")
	label:SetJustifyH("CENTER")
	label:SetTextColor(0.62, 0.62, 0.66)
	label:SetText(text)
	return label
end
head.range = HeadLabel(SurvivorUI_T("Info"))
head.cd = HeadLabel(SurvivorUI_T("CD"))
head.rank = HeadLabel(SurvivorUI_T("Rank"))

-- The dividers, over the rows: from the header's top to the racial's bottom,
-- each at its column's left.
local rules = CreateFrame("Frame", nil, list)
rules:SetAllPoints(list)
rules:SetFrameLevel(list:GetFrameLevel() + 6)
rules.lines = {}
for _, key in pairs({ "rank", "cd", "range", "symbol" }) do
	local line = rules:CreateTexture(nil, "OVERLAY")
	line:SetTexture(FLAT)
	line:SetVertexColor(1, 1, 1, 0.14)
	line:SetWidth(1)
	rules.lines[key] = line
end

-- A column's name, centered over it, never wrapped.
local function PlaceLabel(label, column)
	label:ClearAllPoints()
	if column then
		label:SetPoint("CENTER", head, "RIGHT", -column.right - column.width / 2, 0)
		label:Show()
	else
		label:Hide()
	end
end

local function PlaceHead()
	for key, line in pairs(rules.lines) do
		local column = columns[key]
		line:ClearAllPoints()
		if column then
			-- Between Info's symbols and its numbers, from the rows down only:
			-- the name over them is the two columns'.
			local under = key == "range" and columns.symbol and HEAD_HEIGHT or 0
			line:SetPoint("TOPLEFT", list, "TOPLEFT", 6 + WIDTH - column.divider, -TITLE_HEIGHT - 1 - under)
			line:SetHeight(HEAD_HEIGHT + (SLOTS + 1) * ROW_HEIGHT - 1 - under)
			line:Show()
		else
			line:Hide()
		end
	end
	-- Info's name over its symbols and its numbers together.
	local info = columns.range
	if info and columns.symbol then
		local left = columns.symbol.right + columns.symbol.width
		info = { right = info.right, width = left - info.right }
	end
	PlaceLabel(head.range, info)
	PlaceLabel(head.cd, columns.cd)
	PlaceLabel(head.rank, columns.rank)
end

local function PlaceRow(row)
	PlaceText(row.range, columns.range)
	PlaceText(row.cd, columns.cd)
	PlaceText(row.rank, columns.rank)
	row.name:SetWidth(nameRoom)
end

local rows = {}

local function Row(index)
	local row = rows[index]
	if row then
		return row
	end
	row = CreateFrame("Frame", nil, list)
	row:SetWidth(WIDTH)
	row:SetHeight(ROW_HEIGHT)
	row:SetPoint("TOPLEFT", list, "TOPLEFT", 6, -TITLE_HEIGHT - HEAD_HEIGHT - (index - 1) * ROW_HEIGHT)
	-- A dark base under a spell's color, drawn by the list under the row: the
	-- color reads the same over any ground, as Biggest Crits'.
	row.base = list:CreateTexture(nil, "ARTWORK")
	row.base:SetTexture(FLAT)
	row.base:SetVertexColor(0.05, 0.05, 0.07, 0.92)
	row.base:SetPoint("TOPLEFT", row, "TOPLEFT", 0, -1)
	row.base:SetPoint("BOTTOMRIGHT", row, "BOTTOMRIGHT", 0, 1)
	row.base:Hide()

	row.wash = row:CreateTexture(nil, "BACKGROUND")
	row.wash:SetTexture(FLAT)
	row.wash:SetPoint("TOPLEFT", row, "TOPLEFT", 0, -1)
	row.wash:SetPoint("BOTTOMRIGHT", row, "BOTTOMRIGHT", 0, 1)

	row.rule = row:CreateTexture(nil, "BORDER")
	row.rule:SetTexture(FLAT)
	row.rule:SetHeight(1)
	row.rule:SetPoint("BOTTOMLEFT", row, "BOTTOMLEFT", 0, 0)
	row.rule:SetPoint("BOTTOMRIGHT", row, "BOTTOMRIGHT", 0, 0)

	-- A border for the highest ranks, hidden otherwise.
	row.edges = {}
	for _, side in pairs({ "TOP", "BOTTOM", "LEFT", "RIGHT" }) do
		local line = row:CreateTexture(nil, "OVERLAY")
		line:SetTexture(FLAT)
		if side == "TOP" or side == "BOTTOM" then
			line:SetHeight(1)
			line:SetPoint(side.."LEFT", row, side.."LEFT", 0, 0)
			line:SetPoint(side.."RIGHT", row, side.."RIGHT", 0, 0)
		else
			line:SetWidth(1)
			line:SetPoint("TOP"..side, row, "TOP"..side, 0, 0)
			line:SetPoint("BOTTOM"..side, row, "BOTTOM"..side, 0, 0)
		end
		line:Hide()
		table.insert(row.edges, line)
	end

	row.icon = row:CreateTexture(nil, "ARTWORK")
	row.icon:SetWidth(ROW_HEIGHT - 4)
	row.icon:SetHeight(ROW_HEIGHT - 4)
	row.icon:SetPoint("LEFT", row, "LEFT", 2, 0)
	row.icon:SetTexCoord(0.08, 0.92, 0.08, 0.92)

	row.name = row:CreateFontString(nil, "OVERLAY")
	row.name:SetFont(SurvivorUI_FONT, 9 + FONT_BUMP, "OUTLINE")
	row.name:SetPoint("LEFT", row, "LEFT", ROW_HEIGHT + 2, 0)
	row.name:SetWidth(WIDTH - ROW_HEIGHT - 70)
	row.name:SetHeight(12)
	row.name:SetJustifyH("LEFT")

	row.range = row:CreateFontString(nil, "OVERLAY")
	row.range:SetFont(SurvivorUI_FONT, 8 + FONT_BUMP, "OUTLINE")
	row.range:SetJustifyH("CENTER")
	row.range:SetTextColor(0.6, 0.6, 0.6)

	-- A lasting spell's hourglass or a heal's cross in the Info cell; the part
	-- of a lasting spell's row its time has run out of, and the timer's edge.
	row.glass = row:CreateTexture(nil, "OVERLAY")
	row.glass:SetWidth(9)
	row.glass:SetHeight(9)
	row.glass:Hide()
	row.spent = row:CreateTexture(nil, "BACKGROUND")
	row.spent:SetTexture(FLAT)
	row.spent:Hide()
	row.tick = row:CreateTexture(nil, "BORDER")
	row.tick:SetTexture(FLAT)
	row.tick:SetVertexColor(1, 0.94, 0.78, 0.9)
	row.tick:SetWidth(1)
	row.tick:SetHeight(ROW_HEIGHT - 2)
	row.tick:Hide()

	row.cd = row:CreateFontString(nil, "OVERLAY")
	row.cd:SetFont(SurvivorUI_FONT, 8 + FONT_BUMP, "OUTLINE")
	row.cd:SetJustifyH("CENTER")
	row.cd:SetTextColor(0.6, 0.6, 0.6)

	row.rank = row:CreateFontString(nil, "OVERLAY")
	row.rank:SetFont(SurvivorUI_FONT, 10 + FONT_BUMP, "OUTLINE")
	row.rank:SetJustifyH("CENTER")
	if columns then
		PlaceRow(row)
	end

	-- The spell's tooltip, as on its action button (AbilityTooltip.lua lays it
	-- out): beside the list, towards the screen's middle, level with the row.
	-- Its damage and crits are the damage meter's and Biggest Crits' cards.
	row:EnableMouse(true)
	row:SetScript("OnEnter", function()
		if not (this.ability and this.actionSlot) then
			return
		end
		GameTooltip:SetOwner(this, "ANCHOR_NONE")
		GameTooltip:ClearAllPoints()
		if SurvivorUI_RoomOnRight(list) then
			GameTooltip:SetPoint("TOPLEFT", this, "TOPRIGHT", (list:GetRight() or 0) - (this:GetRight() or 0) + 6, 0)
		else
			GameTooltip:SetPoint("TOPRIGHT", this, "TOPLEFT", -((this:GetLeft() or 0) - (list:GetLeft() or 0)) - 6, 0)
		end
		GameTooltip:SetAction(this.actionSlot)
		GameTooltip:Show()
	end)
	row:SetScript("OnLeave", function() GameTooltip:Hide() end)

	rows[index] = row
	return row
end

local function Border(row, color, alpha)
	for index = 1, table.getn(row.edges) do
		local line = row.edges[index]
		if alpha and alpha > 0 then
			line:SetVertexColor(color[1], color[2], color[3], alpha)
			line:Show()
		else
			line:Hide()
		end
	end
end

-- Words cut to their room at the size they are at, "...", by whole letters
-- (a Russian one two bytes, a Chinese one three), a last scrap of a word
-- (three letters or less) left out, as the Jewelry Collection cuts its names
-- (Jewelry.lua's Fit); after, kept whole behind the "..." (a piece's rank).
-- Width measures words as they would show.
local function Letters(text)
	return string.len((string.gsub(text, "[\128-\191]", "")))
end

local function CutTo(words, room, Width, after)
	after = after or ""
	local count, cut = Letters(words), words
	while count > 1 do
		count = count - 1
		cut = SurvivorUI_Cut(words, count)
		if Width((string.gsub(cut, "%s+$", "")).."..."..after) <= room then
			break
		end
	end
	-- Cut inside a word: three letters or less of it are no help.
	local inside = string.find(string.sub(words, string.len(cut) + 1, string.len(cut) + 1), "%S")
	local _, _, whole, scrap = string.find(cut, "^(.*%S)%s+(%S+)$")
	if inside and whole and Letters(scrap) <= 3 then
		cut = whole
	end
	return (string.gsub(cut, "%s+$", "")).."..."..after
end

-- A spell's name fit to its column, measured (Lucas, 2026-11-04: a Russian
-- one is long, "Автоматическая стрельба"): at its size; else a point smaller,
-- never under 7; the racial's "(racial)" left out when the name alone fits
-- so; else the name cut at its size, "...". Hover the row for its card, its
-- whole name the card's title. Measured on a word of its own, as the name's
-- column cuts what runs past it, and again only as the words, the room, the
-- face or the list's text size change; a name not drawn yet measures
-- nothing, and is fit on the next draw. The size is told to EditCard.lua's
-- Dress as the name's own (base) and as the one it is at, so the text size
-- step is not added twice (as FitTags, below).
local nameProbe = list:CreateFontString(nil, "OVERLAY")
nameProbe:SetFont(SurvivorUI_FONT, 9 + FONT_BUMP, "OUTLINE")
nameProbe:SetPoint("TOPLEFT", list, "TOPLEFT", 7, -6)
nameProbe:SetTextColor(1, 1, 1, 0)

-- The fit itself, the list's and the options' preview's (SurvivorUI_FitBuildName):
-- the size the name goes at (9, or 8 a point smaller; nil: it measured
-- nothing, not drawn yet) and its words, Width(points, words) their width at
-- that size, the text size step in.
local function FitChoice(name, tag, room, step, Width)
	local smaller = math.max(6, 9 + FONT_BUMP + step) > 7
	local whole = tag and (name.."  |cff8a8a8a"..tag.."|r") or name
	local width = Width(9, whole)
	if width == 0 then
		return nil, whole
	end
	if width <= room then
		return 9, whole
	end
	if smaller and Width(8, whole) <= room then
		return 8, whole
	end
	if tag then
		if Width(9, name) <= room then
			return 9, name
		end
		if smaller and Width(8, name) <= room then
			return 8, name
		end
	end
	return 9, CutTo(name, room, function(words)
		return Width(9, words)
	end)
end

local function FitSpell(row, name, tag)
	local step = SurvivorUI_PieceTextStep and SurvivorUI_PieceTextStep("Build list") or 0
	local path, _, flags = row.name:GetFont()
	path, flags = path or SurvivorUI_FONT, flags or "OUTLINE"
	local room = nameRoom
	local key = name.."|"..(tag or "").."|"..math.floor(room + 0.5).."|"..step.."|"..path
	if row.fitKey == key then
		return
	end
	-- The probe's font set only when its size changes (the cut's words all at 9).
	local at
	local function Width(points, words)
		local want = math.max(6, points + FONT_BUMP + step)
		if want ~= at then
			at = want
			nameProbe:SetFont(path, want, flags)
		end
		nameProbe:SetText(words)
		return nameProbe:GetStringWidth()
	end
	local points, words = FitChoice(name, tag, room, step, Width)
	row.fitKey = points and key or nil
	local base = (points or 9) + FONT_BUMP
	local want = math.max(6, base + step)
	row.name:SetFont(path, want, flags)
	row.name.suiBase, row.name.suiSize, row.name.suiPath = base, want, row.name:GetFont()
	row.name:SetText(words)
	nameProbe:SetText("")
end

-- The top spell's name and rank a point larger, a touch brighter; set only
-- when it changes, since setting a font costs the engine every time.
local function Bold(row, bold)
	if row.bold ~= bold then
		row.bold = bold
		row.name:SetFont(SurvivorUI_FONT, 9 + FONT_BUMP + (bold and 1 or 0), "OUTLINE")
		row.rank:SetFont(SurvivorUI_FONT, 10 + FONT_BUMP + (bold and 1 or 0), "OUTLINE")
	end
end

-- A spell's row filled with its color, the text light over it; an empty slot
-- or the racial only a faint wash, the text in the color.
local function Paint(row, color, alpha, filled)
	if filled then
		row.base:Show()
	else
		row.base:Hide()
	end
	if filled then
		row.name:SetTextColor(1, 1, 1)
		row.rank:SetTextColor(1, 1, 1)
		row.range:SetTextColor(0.9, 0.9, 0.9)
		row.cd:SetTextColor(0.9, 0.9, 0.9)
		row.wash:SetVertexColor(color[1], color[2], color[3], 0.45)
	else
		row.name:SetTextColor(color[1], color[2], color[3])
		row.rank:SetTextColor(color[1], color[2], color[3])
		row.range:SetTextColor(0.6, 0.6, 0.6)
		row.cd:SetTextColor(0.6, 0.6, 0.6)
		row.wash:SetVertexColor(color[1], color[2], color[3], 0.07 * alpha)
	end
	row.rule:SetVertexColor(color[1], color[2], color[3], 0.28 * alpha)
end

-- A spell's range, read off its button's tooltip: the short lines over its
-- cast line ("28 yd"; a spell with none, its radius: "11 yd radius"). Kept
-- by its name and rank a few seconds, an upgrade can widen it. And, the
-- second answer, an area's radius: a spell's that lands on a spot ("every
-- enemy within 21 yd of that spot"), what its upgrades widen, or the radius
-- of one with no range at all (around you, a totem's, a burst's).
local scan = CreateFrame("GameTooltip", "SurvivorUIBuildScan", nil, "GameTooltipTemplate")
local reaches = {}              -- [name:rank] = { text or false, when read }

-- The game in another language says the same in its own words (LocaleData.lua,
-- from its tables: SurvivorUI_LOCALE[language].reach): the yards' unit, and
-- each phrase as the words either side of its number, in the language's order
-- ("30码射程": "" and "码射程"). They are compared where each number stands,
-- never sought along a line (a pattern of other scripts' letters sought so
-- hung the game once, v3.0.17). The language not known yet (a race several of
-- them name alike, "Дворф"): every language's words at once.
local reachWords = {}           -- [language, or "?" for all] = { units, range, cone, radius, spot, near }

local function ReachWords(language)
	local words = reachWords[language or "?"]
	if words then
		return words.units[1] and words or nil
	end
	words = { units = {}, range = {}, cone = {}, radius = {}, spot = {}, near = {} }
	local seen = {}
	for code, data in pairs(SurvivorUI_LOCALE or {}) do
		local reach = data.reach
		-- All of them: but those in English's " yd" (Czech's), which English
		-- has read already ("Cast once enemies are within 30 yd" a range else).
		if reach and reach.unit and (code == language or not language and reach.unit ~= " yd") then
			if not seen[reach.unit] then
				seen[reach.unit] = true
				table.insert(words.units, reach.unit)
			end
			for kind, list in pairs(words) do
				local found = kind ~= "units" and reach[kind] or {}
				for index = 1, table.getn(found) do
					table.insert(list, found[index])
				end
			end
		end
	end
	reachWords[language or "?"] = words
	return words.units[1] and words or nil
end

-- The rest of Info in another language, the same way (LocaleData.lua:
-- SurvivorUI_LOCALE[language].info): a heal's share of your max health or its
-- amount, an absorb's amount and a buff's length, each by the patterns of the
-- game's own lines for them, held to the start of the line its description
-- opens ("^Исцеляет вас на .-, ([%d%.,]+)%% макс%."), the number caught in the
-- language's own order; and its word for seconds (" с", "秒"). nil: English,
-- read by its own words below as before.
local function InfoWords(language)
	local data = language and SurvivorUI_LOCALE and SurvivorUI_LOCALE[language]
	return data and data.info
end

-- The number the first of these patterns a line opens with catches, as
-- English writes it ("8.6").
local function OpensWith(text, patterns)
	for index = 1, table.getn(patterns or {}) do
		local _, _, number = string.find(text, patterns[index])
		if number then
			return (string.gsub(number, ",", "."))
		end
	end
end

-- The unit right after a number that ends at last, if one of these: not one
-- a word goes on from (" m" in "5 min").
local function UnitAfter(text, last, units)
	for index = 1, table.getn(units) do
		local unit = units[index]
		local stop = last + string.len(unit)
		if string.sub(text, last + 1, stop) == unit then
			local byte = stop < string.len(text) and string.byte(text, stop + 1)
			if not (byte and (byte >= 65 and byte <= 90 or byte >= 97 and byte <= 122 or byte >= 192 and byte <= 223)) then
				return unit
			end
		end
	end
end

-- Whether one of these phrases stands round the number at first..last: its
-- words before and after it; anchored, the line opening with them.
local function Beside(text, first, last, list, anchored)
	for index = 1, table.getn(list) do
		local before, after = list[index][1], list[index][2]
		local from = first - string.len(before)
		if from >= 1 and (from == 1 or not anchored) and string.sub(text, from, first - 1) == before
				and string.sub(text, last + 1, last + string.len(after)) == after then
			return true
		end
	end
	return false
end

-- A line in another language, read as an English one below: its first yards
-- not those a spell waits for, whether it is a radius's line, one opening
-- with a range or a cone, an area's spot. Into got (range, radius, area,
-- ranged), each kept as first read; the numbers as English writes them.
local function ReadOther(text, words, got)
	local yards, round
	local from = 1
	while true do
		local first, last, number = string.find(text, "(%d+[%.,]?%d*)", from)
		if not first then
			break
		end
		from = last + 1
		if UnitAfter(text, last, words.units) then
			number = string.gsub(number, ",", ".")
			if Beside(text, first, last, words.range, true) or Beside(text, first, last, words.cone, true) then
				got.ranged = true
			end
			if Beside(text, first, last, words.radius, true) then
				round = true
			end
			if not got.area and Beside(text, first, last, words.spot) then
				got.area = number
			end
			if not yards and not Beside(text, first, last, words.near) then
				yards = number
			end
		end
	end
	if yards and round then
		got.radius = got.radius or yards
	elseif yards then
		got.range = got.range or yards
	end
end

local function Reach(actionSlot, name, rank)
	local key = tostring(name)..":"..tostring(rank)
	local known = reaches[key]
	if known and GetTime() - known[2] < 5 then
		return known[1] or nil, known[3]
	end
	scan:SetOwner(WorldFrame, "ANCHOR_NONE")
	scan:ClearLines()
	scan:SetAction(actionSlot)
	local range, radius, area, ranged
	-- The game's language (nil: English, or not known yet) and its words.
	local language = SurvivorUI_Language and SurvivorUI_Language()
	local words = language and ReachWords(language)
	local got, texts = {}, {}
	for line = 2, scan:NumLines() do
		local text = getglobal("SurvivorUIBuildScanTextLeft"..line)
		text = text and text:GetText() or ""
		-- "Cast once enemies are within 30 yd", a totem's "once enemies are
		-- within 25 yd", Blizzard's "once enemies come within 30 yd": where it
		-- is cast from, not how far it reaches.
		text = string.gsub(string.gsub(text, "|c%x%x%x%x%x%x%x%x", ""), "|r", "")
		table.insert(texts, text)
		if words then
			ReadOther(text, words, got)
		else
			local _, _, spot = string.find(text, "within (%d+%.?%d*) yd of that spot")
			area = area or spot
			-- Its header line: "30 yd range", "10 yd radius", "13 yd cone".
			if string.find(text, "^%d+%.?%d* yd range") or string.find(text, "^%d+%.?%d* yd cone") then
				ranged = true
			end
			text = string.gsub(text, "once enemies [ac][ro][em]e? within [%d%.]+ yd", "")
			local _, _, yards = string.find(text, "(%d+%.?%d*) yd")
			if yards then
				if string.find(text, "radius", 1, true) then
					radius = radius or yards
				else
					range = range or yards
				end
			end
		end
	end
	scan:Hide()
	-- No yards read in English and the language not known yet: every
	-- language's words.
	if not language and not (range or radius or area) then
		words = ReachWords(nil)
		for index = 1, words and table.getn(texts) or 0 do
			ReadOther(texts[index], words, got)
		end
	end
	if words then
		range, radius, area, ranged = got.range, got.radius, got.area, got.ranged
	end
	local reach = (range or radius) and ((range or radius).." yd") or false
	if not area and radius and not ranged then
		area = radius
	end
	reaches[key] = { reach, GetTime(), area }
	return reach or nil, area
end

-- Beside each spell (the options, Build list): Info, its symbol, the
-- cooldown and the rank, each on or off. The first builds of v3.0.5-beta.2
-- kept one choice, buildShows.
local function Shows()
	local db = Settings()
	if db.buildShows then
		if db.buildShows == "cooldown" then
			db.buildRange, db.buildCooldown = false, true
		end
		db.buildShows = nil
	end
	return db.buildRange ~= false, db.buildCooldown == true, db.buildSymbols ~= false, db.buildRank ~= false
end

-- A spell's rank as the list shows it: 63, or LXIII with the Roman ranks on
-- (one choice for the whole interface: the options, Tooltips or Build list).
local function RankText(rank)
	rank = tonumber(rank)
	if not rank then
		return ""
	end
	return SurvivorUI_RankText and SurvivorUI_RankText(rank, true) or tostring(rank)
end

-- Whether a text is all ASCII.
local function Ascii(text)
	for index = 1, string.len(text) do
		if string.byte(text, index) > 127 then
			return false
		end
	end
	return true
end

-- A cooldown's number: under a second to two decimals, no zero at the end
-- ("0.25", "0.8"); to 10 sec to one ("3.1"); from 10 none ("12"). The game
-- sends one decimal, so a second one is only ever the floor's 0.25.
local function CooldownNumber(cd)
	if cd >= 10 then
		return string.format("%d", math.floor(cd + 0.5))
	elseif cd >= 1 then
		return string.format("%.1f", cd)
	end
	local text = string.gsub(string.format("%.2f", cd), "0+$", "")
	text = string.gsub(text, "%.$", "")
	return text
end
SurvivorUI_CooldownNumber = CooldownNumber

-- A spell's cooldown as the game has it now, haste in: "0.25s", "3.1s",
-- "12s"; in another language with its own word for seconds, "3.1 с", "12秒",
-- "12 Sek.": where the addon wears a face that writes it
-- (SurvivorUI_LANGUAGE_FONTS) or it needs none ("s", "sn"); Ukrainian's "с"
-- and Korean's "초" not yet. At its floor, the floor: the game sends 0.25 as
-- 0.2 (FloorHourglass.lua, SurvivorUI_TrueCooldown, by the spell's key).
local function CooldownText(entry)
	local cd = tonumber(Field(entry, "cdmax", 5)) or 0
	if cd <= 0 then
		return ""
	end
	if SurvivorUI_TrueCooldown then
		cd = SurvivorUI_TrueCooldown(Field(entry, "key", 1), cd)
	end
	local language = SurvivorUI_Language and SurvivorUI_Language()
	local words = InfoWords(language)
	local sec = words and words.sec
	if sec and not (SurvivorUI_LANGUAGE_FONTS and SurvivorUI_LANGUAGE_FONTS[language] or Ascii(sec[1]..sec[2])) then
		sec = nil
	end
	if sec then
		return sec[1]..CooldownNumber(cd)..sec[2]
	end
	return CooldownNumber(cd).."s"
end

-- The cooldowns, all alike, a point smaller when the language's words make
-- one wider than its column ("8.6 Sek."), then without the space before the
-- word ("8.6Sek."), then a point smaller again: each text measured once, on a
-- probe; the rows' font set only when that changes (see Bold). English's fit.
local CD_STEPS = { { 8 }, { 7 }, { 7, true }, { 6, true } }   -- size, the space out
local cdProbe = list:CreateFontString(nil, "OVERLAY")
cdProbe:Hide()
local cdSteps = {}               -- [face, column width, text] = the first step it fits at

local function Spaceless(text)
	return (string.gsub(text, " ", ""))
end

-- The first step a text fits its column's width at, Width(points, words) its
-- width at that size (the list's probe, or the options' preview's words).
local function StepOf(text, width, Width)
	local step = 1
	while step < table.getn(CD_STEPS) do
		if Width(CD_STEPS[step][1], CD_STEPS[step][2] and Spaceless(text) or text) <= width then
			break
		end
		step = step + 1
	end
	return step
end

local function CooldownStep(text, face, flags, column, textStep)
	local key = face.."|"..column.width.."|"..textStep.."|"..text
	if not cdSteps[key] then
		cdSteps[key] = StepOf(text, column.width, function(points, words)
			cdProbe:SetFont(face, math.max(6, points + FONT_BUMP + textStep), flags)
			cdProbe:SetText(words)
			return cdProbe:GetStringWidth()
		end)
	end
	return cdSteps[key]
end

-- row.cdText keeps the cooldown as written (its cell may show it spaceless).
local function FitCooldown(row)
	local column = columns and columns.cd
	local text = row.cd:GetText()
	local textStep = SurvivorUI_PieceTextStep and SurvivorUI_PieceTextStep("Build list") or 0
	row.cdText, row.cdStep = text, 1
	local face, _, flags = row.cd:GetFont()
	face, flags = face or SurvivorUI_FONT, flags or "OUTLINE"
	if column and text and text ~= "" and SurvivorUI_Language and SurvivorUI_Language() then
		row.cdStep = CooldownStep(text, face, flags, column, textStep)
	end
	local step = 1
	for _, each in pairs(rows) do
		local shown = each:IsShown() and each.cd:GetText()
		if shown and shown ~= "" and each.cdStep then
			step = math.max(step, each.cdStep)
		end
	end
	local size, spaceless = CD_STEPS[step][1], CD_STEPS[step][2]
	for _, each in pairs(rows) do
		if (each.cdSize or 8) ~= size then
			each.cdSize = size
			-- At the text size step, told to EditCard.lua's Dress as its own (as FitSpell).
			local face, _, flags = each.cd:GetFont()
			local base = size + FONT_BUMP
			each.cd:SetFont(face or SurvivorUI_FONT, math.max(6, base + textStep), flags or "OUTLINE")
			each.cd.suiBase, each.cd.suiSize, each.cd.suiPath = base, math.max(6, base + textStep), each.cd:GetFont()
		end
		local shown = each.cd:GetText()
		if shown and shown ~= "" and each.cdText then
			local want = spaceless and Spaceless(each.cdText) or each.cdText
			if shown ~= want then
				each.cd:SetText(want)
			end
		end
	end
end

------------------------------------------------------------------------------
-- A spell whose time it lasts matters more than its reach (option A of the
-- build list's mockup, 2026-10-21): in its range cell an hourglass and its
-- length in gold, "8"; while it is up its row drains as a timer, the cell
-- counting down, "5.2". Buffs only (Divine Shield, Holy Shield, Battle Shout,
-- Slice and Dice, Adrenaline Rush, Lightning Shield, Thorns, and your demons'
-- Demonic Empowerment, which the game may not list among your own buffs, so
-- its length only; the shields' and the shout's reach is only where they are
-- cast from); a weakening on the enemies, Demoralizing Shout's, was tried and
-- left out. Its length is the game's: the time
-- left as its buff last went up (AZS_BUFFS, by its spell id
-- in AZS_SPELLS; kept for the account, an upgrade can lengthen it), else read
-- off its tooltip ("for 8 sec", "For 14 sec"; another language's by its
-- patterns, InfoWords).

local LASTING = { divine_shield = true, holy_shield = true, battle_shout = true,
	slice_and_dice = true, adrenaline_rush = true, lightning_shield = true, thorns = true,
	demonic_empowerment = true }
local HOURGLASS = { 1, 0.84, 0.43 }
local buffs = { last = {} }      -- the run time the buffs were last told at; each spell's left then
local timing = false             -- a lasting spell up: the list drawn more often

local function RunSeconds()
	return AZS_GetRunTime and AZS_GetRunTime() or GetTime()
end

-- The seconds left on a spell's buff now, and its length as last seen.
local function Lasting(entry, key)
	local db = Settings()
	db.buildLasting = db.buildLasting or {}
	if AZS_BUFFS_UPDATED ~= buffs.seen then
		buffs.seen, buffs.at = AZS_BUFFS_UPDATED, RunSeconds()
	end
	local id = tonumber(Field(entry, "spell", 2))
	local left
	for index = 1, table.getn(AZS_BUFFS or {}) do
		local buff = AZS_BUFFS[index]
		if id and tonumber(Field(buff, "spell", 1)) == id then
			left = tonumber(Field(buff, "left", 2)) or 0
		end
	end
	-- Gone up, or up again: the time it has left is its length.
	if left and left > (buffs.last[key] or 0) + 0.3 then
		db.buildLasting[key] = math.floor(left * 10 + 0.5) / 10
	end
	buffs.last[key] = left
	if left then
		left = left - (RunSeconds() - (buffs.at or RunSeconds()))
	end
	return left and left > 0 and left or nil, db.buildLasting[key]
end

------------------------------------------------------------------------------
-- A heal on yourself (2026-10-21): how much of your health it gives back says
-- more than a range it has none of (Holy Light at once, Renew over its time). A green cross and its share, "48%", off
-- its tooltip ("48% of your max health"), else its amount ("Heals you for 287");
-- in another language by its patterns (InfoWords).

local HEALING = { holy_light = true, renew = true, healing_wave = true, rejuvenation = true, regrowth = true }
local CROSS = { 0.42, 1, 0.5 }
-- An absorb on yourself, Power Word: Shield's: how much of your health it
-- holds back, "25%", under a blue shield (it lasts until it breaks, so no
-- hourglass); else its amount ("Absorbs the next 120 damage").
-- Each with the words its amount follows in its tooltip.
local ABSORBING = { pw_shield = "[Aa]bsorbs the next (%d+)", ice_barrier = "up to (%d+)" }
local SHIELD = { 0.59, 0.82, 1 }
-- And a range or a radius, "22 yd", under a measuring arrow in gray, |<->| (idea C):
-- the most common, so the plainest; each color one meaning, gold a time, green
-- a heal, blue a shield.
local RANGE = { 0.8, 0.8, 0.83 }
local heals = {}                 -- [name:rank] = { text or false, when read }

-- For the options' preview (Build list tab): the list's measures, its empty
-- slots' color, each symbol's tint and the color its number takes (none: the
-- row's own). Read only.
SurvivorUI_BUILD_LOOK = {
	width = WIDTH, row = ROW_HEIGHT, title = TITLE_HEIGHT, head = HEAD_HEIGHT, slots = SLOTS, muted = MUTED, rankWidth = COLUMN_WIDTH.rank,
	tints = { Range = RANGE, Area = RANGE, Hourglass = HOURGLASS, HealCross = CROSS, Shield = SHIELD },
	numbers = { Hourglass = HOURGLASS, HealCross = CROSS, Shield = SHIELD },
}

-- A tooltip's line as plain text, its colors taken out.
local function Plain(text)
	text = string.gsub(text or "", "|c%x%x%x%x%x%x%x%x", "")
	return (string.gsub(text, "|r", ""))
end

local function HealText(actionSlot, name, rank, amountPattern)
	local key = tostring(name)..":"..tostring(rank)
	local known = heals[key]
	if known and GetTime() - known[2] < 5 then
		return known[1] or nil
	end
	scan:SetOwner(WorldFrame, "ANCHOR_NONE")
	scan:ClearLines()
	scan:SetAction(actionSlot)
	local share, amount
	-- The game's language (nil: English) and its patterns: an absorb's amount
	-- (amountPattern given) or a heal's.
	local words = InfoWords(SurvivorUI_Language and SurvivorUI_Language())
	for line = 2, scan:NumLines() do
		local text = getglobal("SurvivorUIBuildScanTextLeft"..line)
		text = Plain(text and text:GetText())
		local _, p, n
		if words then
			p, n = OpensWith(text, words.share), OpensWith(text, words[amountPattern and "absorb" or "heal"])
		else
			_, _, p = string.find(text, "(%d+%.?%d*)%% of your max health")
			_, _, n = string.find(text, amountPattern or "[Hh]eals you for (%d+)")
		end
		share, amount = share or p, amount or n
	end
	scan:Hide()
	local shown = share and (share.."%") or amount or false
	heals[key] = { shown, GetTime() }
	return shown or nil
end

-- Its length off its tooltip, before the game has shown it once.
local lengths = {}               -- [name:rank] = seconds, or false
local function TipLength(actionSlot, name, rank)
	local key = tostring(name)..":"..tostring(rank)
	if lengths[key] == nil then
		lengths[key] = false
		scan:SetOwner(WorldFrame, "ANCHOR_NONE")
		scan:ClearLines()
		scan:SetAction(actionSlot)
		local words = InfoWords(SurvivorUI_Language and SurvivorUI_Language())
		for line = 2, scan:NumLines() do
			local text = getglobal("SurvivorUIBuildScanTextLeft"..line)
			local _, secs
			if words then
				secs = OpensWith(Plain(text and text:GetText()), words.length)
			else
				_, _, secs = string.find(Plain(text and text:GetText()), "[Ff]or (%d+%.?%d*) sec")
			end
			if secs and not lengths[key] then
				lengths[key] = tonumber(secs)
			end
		end
		scan:Hide()
	end
	return lengths[key] or nil
end

-- The hourglass stands for the seconds: "8" or "5.5" beside it, no "s".
local function Length(seconds)
	if math.mod(seconds, 1) == 0 then
		return string.format("%d", seconds)
	end
	return string.format("%.1f", seconds)
end

-- The Info cell's number, centered as every column's, and its symbol in its
-- tint, centered in the symbols' column at its left: the hourglass, the cross,
-- the shield, the measuring arrow, the ring of an area.
local function PlaceReach(row, symbol, tint)
	local column = columns and columns.range
	local place = columns and columns.symbol
	row.range:ClearAllPoints()
	if not column then
		row.glass:Hide()
		row.range:Hide()
		return
	end
	row.range:SetPoint("RIGHT", row, "RIGHT", -column.right, 0)
	row.range:SetWidth(column.width)
	row.range:SetJustifyH("CENTER")
	row.range:Show()
	if symbol and place then
		if row.symbol ~= symbol then
			row.symbol = symbol
			row.glass:SetTexture(ART..symbol)
		end
		-- Square between the column's two dividers, on whole pixels: 15 free
		-- between them, 3 either side of the 9 of the symbol.
		row.glass:ClearAllPoints()
		row.glass:SetPoint("RIGHT", row, "RIGHT", -place.right - 1, 0)
		row.glass:SetVertexColor(tint[1], tint[2], tint[3])
		row.glass:Show()
	else
		row.glass:Hide()
	end
end

-- The row as a timer: its color as far as the time left reaches, the rest
-- faint, a bright edge between; whole again otherwise.
local function Drain(row, share, color)
	row.wash:ClearAllPoints()
	row.wash:SetPoint("TOPLEFT", row, "TOPLEFT", 0, -1)
	if share then
		local x = math.max(1, WIDTH * share)
		row.wash:SetPoint("BOTTOMRIGHT", row, "BOTTOMLEFT", x, 1)
		row.spent:ClearAllPoints()
		row.spent:SetPoint("TOPLEFT", row, "TOPLEFT", x, -1)
		row.spent:SetPoint("BOTTOMRIGHT", row, "BOTTOMRIGHT", 0, 1)
		row.spent:SetVertexColor(color[1], color[2], color[3], 0.12)
		row.spent:Show()
		row.tick:ClearAllPoints()
		row.tick:SetPoint("TOP", row, "TOPLEFT", x, -1)
		row.tick:Show()
	else
		row.wash:SetPoint("BOTTOMRIGHT", row, "BOTTOMRIGHT", 0, 1)
		row.spent:Hide()
		row.tick:Hide()
	end
end

-- A lasting spell's cell: its time left while it is up, else its length; the
-- number, its color, and while it is up the share of its time left.
local BRIGHT = { 1, 1, 1 }

local function LastingCell(entry, key, actionSlot, name, showRange)
	local left, length = Lasting(entry, key)
	length = length or TipLength(actionSlot, name, Field(entry, "rank", 3))
	if left then
		return showRange and string.format("%.1f", left) or "", BRIGHT, length and math.min(1, left / length) or 1
	end
	return showRange and length and Length(length) or "", HOURGLASS
end

-- Returns the share of its time left, for the row's timer.
local function FillLasting(row, entry, key, actionSlot, name, showRange)
	local text, color, share = LastingCell(entry, key, actionSlot, name, showRange)
	if share then
		timing = true
	end
	row.range:SetText(text)
	row.range:SetTextColor(color[1], color[2], color[3])
	return share
end

-- What the Info cell holds, as Fill draws it: whether the spell is a lasting
-- one (its number then LastingCell's), its symbol (an Art file) and tint, its
-- number, and the number's color (none: the row's own).
-- The kinds Info leaves out (the options, Build list: buildInfoOff, by
-- symbol): such a spell shows its reach instead, as any spell's (a buff's
-- row then no timer); the reach left out, nothing.
local SHOWS_ALL = {}

local function InfoOf(entry, key, actionSlot, name, isRacial, showRange)
	local rank = Field(entry, "rank", 3)
	local off = Settings().buildInfoOff or SHOWS_ALL
	local lasting = LASTING[key] and not isRacial and not off.Hourglass
	if lasting and showRange then
		-- Up, or its length known or told; else its range, as any spell's.
		local left, length = Lasting(entry, key)
		lasting = (left or length or TipLength(actionSlot, name, rank)) and true
	end
	if lasting then
		return true, showRange and "Hourglass", HOURGLASS
	end
	-- A heal's or an absorb's share of your health, when its tooltip tells it;
	-- else its range, as any spell's.
	local healing = HEALING[key] and not isRacial and showRange and not off.HealCross and HealText(actionSlot, name, rank)
	if healing then
		return false, "HealCross", CROSS, healing, CROSS
	end
	local absorbing = ABSORBING[key] and not isRacial and showRange and not off.Shield and HealText(actionSlot, name, rank, ABSORBING[key])
	if absorbing then
		return false, "Shield", SHIELD, absorbing, SHIELD
	end
	-- The measuring arrow stands for the yards: "22" beside it, not "22 yd".
	-- An area (landing on a spot, around you, a totem's, a burst's): its
	-- radius, under a ring.
	local reach, area = nil, nil
	if showRange then
		reach, area = Reach(actionSlot, name, rank)
	end
	if area and not off.Area then
		return false, "Area", RANGE, area
	end
	if off.Range then
		return false, nil, RANGE, ""
	end
	return false, reach and "Range", RANGE, reach and (string.gsub(reach, " yd$", "")) or ""
end

local function Fill(row, entry, actionSlot, isRacial)
	local key = Field(entry, "key", 1)
	local name = SpellName(key)
	local color = SurvivorUI_MeterColor and SurvivorUI_MeterColor(name) or { 0.8, 0.8, 0.8 }
	row.ability, row.color = name, color
	-- Its tooltip is its action button's; the racial's tells the race's
	-- traits too (AbilityTooltip.lua).
	row.racial = isRacial
	row.actionSlot = actionSlot
	row.icon:SetTexture(GetActionTexture and GetActionTexture(actionSlot) or nil)
	row.icon:SetAlpha(1)
	-- Its name as the game writes it in its language (Locale.lua).
	local shown = SurvivorUI_Native(name)
	FitSpell(row, shown, isRacial and SurvivorUI_T("(racial)"))
	row.rank:SetText(RankText(Field(entry, "rank", 3)))
	local showRange, showCooldown = Shows()
	local lasting, symbol, tint, number, numberColor = InfoOf(entry, key, actionSlot, name, isRacial, showRange)
	PlaceReach(row, symbol, tint)
	if not lasting then
		row.range:SetText(number)
	end
	row.cd:SetText(showCooldown and CooldownText(entry) or "")
	FitCooldown(row)
	Paint(row, color, isRacial and 0.5 or 1, not isRacial)
	if numberColor then
		row.range:SetTextColor(numberColor[1], numberColor[2], numberColor[3])
	end
	Drain(row, lasting and FillLasting(row, entry, key, actionSlot, name, showRange), color)
	row:Show()
end

local function Empty(row)
	row.ability, row.color, row.racial = nil, nil, nil
	row.icon:SetTexture(FLAT)
	row.icon:SetVertexColor(0.15, 0.15, 0.18)
	row.icon:SetAlpha(0.8)
	FitSpell(row, SurvivorUI_T("empty slot"))
	row.rank:SetText("")
	PlaceReach(row, false)
	row.range:SetText("")
	row.cd:SetText("")
	Paint(row, MUTED, 0.6)
	Drain(row, nil)
	row:Show()
end

------------------------------------------------------------------------------
-- The race's traits, as the game tells them in the chat as a run begins:
-- "- Berserking: every 35 sec, cooldowns recover 30% faster for 10 sec",
-- "- Regeneration: +1.5 health per second". Read before the run starts (its
-- lines come then), kept by race for the account, a new run's list in place
-- of the last; for the racial's card (RunPanel.lua: SurvivorUI_Racials).

local function Racials()
	local db = Settings()
	db.racials = db.racials or {}
	return db.racials
end

local function RaceKey()
	local _, race = UnitRace("player")
	return race or "?"
end

local function ReadRacial(text)
	if not text then
		return
	end
	local phase = AZS_GetPhase and AZS_GetPhase()
	if phase and phase ~= "ready" then
		return
	end
	local plain = string.gsub(text, "|c%x%x%x%x%x%x%x%x", "")
	plain = string.gsub(plain, "|r", "")
	local _, _, name, desc = string.find(plain, "^%- ([^:]+): (.+)$")
	if not name then
		return
	end
	local racials = Racials()
	local key = RaceKey()
	local entry = racials[key]
	-- A list older than a minute is a run before: this one starts it again.
	local now = time and time() or GetTime()
	if not entry or math.abs(now - (entry.at or 0)) > 60 then
		entry = { at = now, traits = {} }
		racials[key] = entry
	end
	for _, trait in pairs(entry.traits) do
		if trait.name == name then
			trait.text = desc
			return
		end
	end
	table.insert(entry.traits, { name = name, text = desc })
end

-- The race's name and its traits, nil until a run has told them.
function SurvivorUI_Racials()
	local entry = Racials()[RaceKey()]
	return UnitRace("player"), entry and entry.traits
end

-- By the system's line, and by the chat window's, for a line no event brings.
local racialWatch = CreateFrame("Frame")
racialWatch:RegisterEvent("CHAT_MSG_SYSTEM")
racialWatch:RegisterEvent("PLAYER_ENTERING_WORLD")
racialWatch:SetScript("OnEvent", function()
	if event == "PLAYER_ENTERING_WORLD" then
		local frame = DEFAULT_CHAT_FRAME
		if frame and not frame.survivorRacialWatched then
			frame.survivorRacialWatched = true
			local stock = frame.AddMessage
			frame.AddMessage = function(self, text, r, g, b, id, hold)
				ReadRacial(text)
				return stock(self, text, r, g, b, id, hold)
			end
		end
		return
	end
	ReadRacial(arg1)
end)

-- The slotted spells from the highest rank down, ties to the earlier slot.
local function RankOrder(spells, slotted)
	local order = {}
	for index = 1, slotted do
		table.insert(order, index)
	end
	table.sort(order, function(a, b)
		local ra = tonumber(Field(spells[a], "rank", 3)) or 0
		local rb = tonumber(Field(spells[b], "rank", 3)) or 0
		if ra ~= rb then
			return ra > rb
		end
		return a < b
	end)
	return order
end

-- Roman ranks: the rank column as wide as the longest of them needs
-- (LXXXVIII), a number's at least; measured on a word of its own (at the
-- ranks' size, the piece's text size too) as the ranks change, the rows laid
-- out again on the next draw.
local probe = list:CreateFontString(nil, "OVERLAY")
probe:SetFont(SurvivorUI_FONT, 10 + FONT_BUMP, "OUTLINE")
probe:SetPoint("TOPLEFT", list, "TOPLEFT", 7, -6)
probe:SetTextColor(1, 1, 1, 0)
local measured = {}

local function RankRoom()
	if not SurvivorUIDB.romanRanks then
		return COLUMN_WIDTH.rank
	end
	local _, size = probe:GetFont()
	local key = tostring(size)
	for index = 1, SLOTS + 1 do
		if rows[index] and rows[index]:IsShown() then
			key = key.."|"..(rows[index].rank:GetText() or "")
		end
	end
	if measured.key ~= key then
		local widest = 0
		for word in string.gfind(key, "|([^|]*)") do
			probe:SetText(word)
			widest = math.max(widest, probe:GetStringWidth() or 0)
		end
		probe:SetText("")
		-- Not drawn yet, it measures nothing: measured again next time.
		measured.key = widest > 0 and key or nil
		measured.width = math.max(COLUMN_WIDTH.rank, math.ceil(widest) + 4)
	end
	return measured.width
end

local function Draw()
	timing = false
	-- The columns as chosen; changed, every row laid out again.
	if Columns(Shows()) then
		PlaceHead()
		for index = 1, table.getn(rows) do
			PlaceRow(rows[index])
		end
	end
	local spells = AZS_SPELLS or {}
	local count = table.getn(spells)
	-- The racial comes last in the game's list and takes no slot.
	local slotted = math.max(0, count - 1)
	-- The three highest ranks among the slotted spells, ties to the earlier
	-- slot: the first bold with a full border, the second a full border, the
	-- third a faint one; the rest plain. The list itself runs in that order.
	local order = RankOrder(spells, slotted)
	-- Rows from the highest rank down; each spell keeps its own action button
	-- for its icon.
	for place = 1, SLOTS do
		local row = Row(place)
		row.icon:SetVertexColor(1, 1, 1)
		local index = order[place]
		if index then
			Fill(row, spells[index], Slot(index, count), false)
		else
			Empty(row)
		end
	end
	-- Every spell the same border in its color; the order says the rest.
	for slot = 1, SLOTS do
		local row = rows[slot]
		if order[slot] then
			Border(row, row.color, 0.6)
		else
			Border(row, nil, 0)
		end
	end
	local racialRow = Row(SLOTS + 1)
	racialRow.icon:SetVertexColor(1, 1, 1)
	if count >= 1 then
		Fill(racialRow, spells[count], Slot(count, count), true)
	else
		racialRow.base:Hide()
		racialRow:Hide()
	end
	list.count:SetText((slotted >= SLOTS and "|cffff8080" or "|cffd0d0d0")..math.min(slotted, SLOTS).." / "..SLOTS.."|r")
	rankWidth = RankRoom()
end

------------------------------------------------------------------------------
-- The gear: each piece of jewelry and what it gives, in short.

-- Words in a tooltip line and their short names, the more specific first.
local STAT_WORDS = {
	{ "stun duration", "STUN" }, { "stun", "STUN" }, { "root", "ROOT" },
	{ "shields you", "SHIELD" }, { "absorb", "ABSORB" }, { "weaken", "WEAK" },
	{ "explode", "BOOM" }, { "leap", "LEAP" }, { "splash", "SPLASH" }, { "burn and bleed", "BLEED" },
	{ "strike again", "AGAIN" }, { "duration", "DUR" },
	{ "you kill restores", "HP/KILL" }, { "kill heals", "HP/KILL" }, { "each kill", "HP/KILL" },
	{ "damage dealt heals", "LEECH" }, { "of all damage dealt", "LEECH" }, { "leech", "LEECH" },
	{ "critical strike damage", "CRIT DMG" }, { "critical damage", "CRIT DMG" },
	{ "damage of your critical", "CRIT DMG" }, { "critical strikes deal", "CRIT DMG" },
	{ "critical", "CRIT" }, { "crit", "CRIT" }, { "cooldown", "CDR" },
	{ "damage reduction", "DMG RED" }, { "damage taken", "DMG RED" }, { "armor", "DMG RED" },
	{ "area", "AREA" }, { "target", "TGT" }, { "twice", "ECHO" }, { "echo", "ECHO" },
	{ "movement", "SPD" }, { "speed", "SPD" }, { "per second", "REGEN" }, { "regen", "REGEN" },
	{ "health", "HP" }, { "pickup", "PICK" }, { "pick up", "PICK" }, { "experience", "XP" }, { "gold", "GOLD" },
	{ "luck", "LUCK" }, { "heal", "HEAL" }, { "thorns", "THORNS" },
	{ "live", "LIFE" }, { "damage", "DMG" },
}

-- A line's number as it reads, with its sign: "+24%", "-19%". A line that
-- gives more without a sign ("strikes 1 more target", "increases ... by 24%")
-- gets a +. A leap's count and its share: "2x36%".
local MORE_WORDS = { "more", "increase", "improve", "restore", "heals" }
local function Value(tag, text)
	local _, _, value = string.find(text, "([%+%-]?%d+%.?%d*%%?)")
	if not value then
		return nil
	end
	if tag == "LEAP" then
		local _, last = string.find(text, value, 1, true)
		local _, _, share = string.find(text, "(%d+%.?%d*%%)", (last or 0) + 1)
		return share and (value.."x"..share) or value
	end
	local first = string.sub(value, 1, 1)
	if first ~= "+" and first ~= "-" then
		for _, word in pairs(MORE_WORDS) do
			if string.find(text, word, 1, true) then
				return "+"..value
			end
		end
	end
	return value
end

-- How a bonus reads in the list: the number first, then its word; a leap the
-- other way round, its two numbers together; a stun or a root its word first
-- and its seconds (STUN 1.5s), or the chance of it (STUN 20%). The word in
-- the game's language where the addon speaks it.
local CONTROL = { STUN = true, ROOT = true }
local function Tagged(english, value)
	local tag = SurvivorUI_T(english)
	if not value then
		return tag
	elseif english == "LEAP" then
		return tag.." "..value
	elseif CONTROL[english] then
		if string.find(value, "%", 1, true) then
			return tag.." "..value
		end
		return tag.." "..value.."s"
	end
	return value.." "..tag
end

-- The short name a tooltip line gives: the first word of the list it names,
-- in the list's order, so "+29% critical strike damage" is CRIT DMG, not CRIT.
local function StatOf(text)
	for index = 1, table.getn(STAT_WORDS) do
		if string.find(text, STAT_WORDS[index][1], 1, true) then
			return STAT_WORDS[index][2]
		end
	end
end

-- The same short names for the jewelry collection (Jewelry.lua).
function SurvivorUI_StatOf(text)
	return StatOf(string.lower(text or ""))
end

-- A jewelry line kept in English (a run's, in Run History) in the game's
-- language where the addon speaks it: its slot ("Ring  II"), or its short
-- words ("+30% LUCK · +25% GOLD"), the longer ones first (CRIT DMG before CRIT).
local tagOrder
function SurvivorUI_GearWords(text)
	if not (text and SurvivorUI_Translated()) then
		return text
	end
	local _, _, slot, rest = string.find(text, "^(%a+)(  .*)$")
	if slot then
		return SurvivorUI_T(slot)..rest
	end
	if not tagOrder then
		local seen = {}
		tagOrder = {}
		for index = 1, table.getn(STAT_WORDS) do
			local tag = STAT_WORDS[index][2]
			if not seen[tag] then
				seen[tag] = true
				table.insert(tagOrder, tag)
			end
		end
		table.sort(tagOrder, function(a, b) return string.len(a) > string.len(b) end)
	end
	for index = 1, table.getn(tagOrder) do
		text = string.gsub(text, tagOrder[index], SurvivorUI_T(tagOrder[index]))
	end
	return SurvivorUI_T(text)
end

local scan = CreateFrame("GameTooltip", "SurvivorUIScanTip", nil, "GameTooltipTemplate")
scan:SetOwner(WorldFrame, "ANCHOR_NONE")

-- Each worn piece, by its link: its rank, the Roman numeral that ends its name
-- ("Blackhand's Breadth IV"); the spell a legendary amulet boosts, named after
-- its colon ("Amulet of the Inferno: Consecration IV"); and what it gives, the
-- tooltip's lines with a number in them. An upgrade renames the piece, so the
-- link alone says when to read it again.
local pieces = {}               -- [item link] = { rank, spell, tags }

-- A name or bonus line in English, whatever language the game is in (Locale.lua).
local function English(name)
	return SurvivorUI_English and SurvivorUI_English(name) or name
end

local function EnglishLine(text)
	return SurvivorUI_EnglishLine and SurvivorUI_EnglishLine(text) or text
end

-- What a piece gives in short, off its lines in English (lower case): each
-- line with a number in it by its short name, once each, "+61% DMG · -24% CDR".
local function TagsOf(lines)
	local tags, seen = {}, {}
	for index = 1, table.getn(lines) do
		local text = lines[index]
		if string.find(text, "%d") then
			local tag = StatOf(text)
			if tag and not seen[tag] then
				seen[tag] = true
				table.insert(tags, Tagged(tag, Value(tag, text)))
			end
		end
	end
	return table.concat(tags, " · ")
end

-- This game does not put the run's jewelry in the character's slots: it tells
-- it in AZS_GEAR ({ slot = "ring"/"trinket"/"amulet", name, rarity, amount,
-- text, icon } each). A slot with no item is filled from there: the first ring
-- in 11, the second in 12, the trinkets in 13 and 14, the amulet in 2.
SurvivorUI_SERVER_KIND = { [2] = "amulet", [11] = "ring", [12] = "ring", [13] = "trinket", [14] = "trinket" }
function SurvivorUI_ServerPiece(slot)
	local kind, nth, seen = SurvivorUI_SERVER_KIND[slot], (slot == 12 or slot == 14) and 2 or 1, 0
	local gear = type(AZS_GEAR) == "table" and AZS_GEAR or {}
	for index = 1, table.getn(gear) do
		local g = gear[index]
		if type(g) == "table" and g.slot == kind then
			seen = seen + 1
			if seen == nth then
				return g
			end
		end
	end
end

-- The link of the piece in a slot: the item's own, or one made of the server's
-- piece ("|Hazs:"), in its rarity's color; and that piece, when it is one.
function SurvivorUI_WornLink(slot)
	local link = GetInventoryItemLink and GetInventoryItemLink("player", slot)
	if link then
		return link
	end
	local g = SurvivorUI_ServerPiece(slot)
	if not g then
		return nil
	end
	local color = AZS_GEN and AZS_GEN.rarityColor and AZS_GEN.rarityColor[g.rarity] or "ffffffff"
	return "|c"..color.."|Hazs:"..slot.."|h["..tostring(g.name or g.bonus or "?").."]|h|r", g
end

function SurvivorUI_WornIcon(slot)
	local icon = GetInventoryItemTexture and GetInventoryItemTexture("player", slot)
	if icon then
		return icon
	end
	local g = SurvivorUI_ServerPiece(slot)
	return g and g.icon and g.icon ~= "" and ("Interface\\Icons\\"..g.icon) or nil
end

local function ReadPiece(slot, link)
	if string.find(link, "|Hazs:", 1, true) then
		local g = SurvivorUI_ServerPiece(slot) or {}
		local text = tostring(g.text or "")
		local key = link.."|"..text.."|"..tostring(g.amount)
		if not pieces[key] then
			local lines = {}
			string.gsub(text.." \194\183 ", "(.-) \194\183 ", function(part)
				table.insert(lines, string.lower(part))
			end)
			local tags = TagsOf(lines)
			pieces[key] = { rank = g.slot == "amulet" and tostring(g.amount or 1) or "", tags = tags ~= "" and tags or text }
		end
		return pieces[key]
	end
	if pieces[link] then
		return pieces[link]
	end
	local _, _, name = string.find(link, "%[(.-)%]")
	name = name or ""
	-- Past rank X the name says "X+", and so does the row.
	local _, _, rank = string.find(name, " ([IVXL]+%+?)$")
	if rank then
		name = string.sub(name, 1, string.len(name) - string.len(rank) - 1)
	end
	name = English(name)
	-- Only a legendary amulet names a spell: one for each spell of each class.
	local spell
	if slot == 2 and string.find(link, "|cffff8000", 1, true) then
		_, _, spell = string.find(name, ": (.+)$")
	end
	scan:SetOwner(WorldFrame, "ANCHOR_NONE")
	scan:ClearLines()
	scan:SetInventoryItem("player", slot)
	local lines = {}
	for index = 2, scan:NumLines() do
		local line = getglobal("SurvivorUIScanTipTextLeft"..index)
		table.insert(lines, line and string.lower(EnglishLine(line:GetText() or "")) or "")
	end
	pieces[link] = { rank = rank or "I", spell = spell, tags = TagsOf(lines) }
	return pieces[link]
end

local GEAR_TOP, GEAR_ROW = 21, 17

-- How a piece's quality color shows (the options, Jewelry worn): filling its
-- row, as at first; in its words over a plain row; or not at all; and an empty
-- slot, faint. The row's fill and edge, plain (grey) or in the color.
local GEAR_PAINT = {
	row = { fill = 0.45, edge = 0.7 },
	words = { fill = 0.1, edge = 0.3, plain = true, words = true },
	none = { fill = 0.16, edge = 0.4, plain = true },
	empty = { fill = 0.06, edge = 0.15, plain = true },
}
local PLAIN = { 0.5, 0.5, 0.55 }
-- For the options' preview: the panel's measures and its looks.
SurvivorUI_BUILD_LOOK.gear = { top = GEAR_TOP, row = GEAR_ROW, slots = table.getn(GEAR_SLOTS), paint = GEAR_PAINT, plain = PLAIN }

local worn = CreateFrame("Frame", "SurvivorUIWorn", UIParent)
worn:SetWidth(WIDTH + 12)
worn:SetHeight(GEAR_TOP + table.getn(GEAR_SLOTS) * GEAR_ROW + 5)
worn:SetBackdrop({ bgFile = FLAT })
worn:SetBackdropColor(0.04, 0.04, 0.07, 0.55)
worn:SetMovable(true)
worn:Hide()

worn.title = worn:CreateFontString(nil, "OVERLAY")
worn.title:SetFont(SurvivorUI_FONT, 9 + FONT_BUMP, "OUTLINE")
worn.title:SetPoint("TOPLEFT", worn, "TOPLEFT", 7, -6)
worn.title:SetTextColor(1, 0.82, 0)
worn.title:SetText(SurvivorUI_T("Jewelry"))

-- Each panel's dark ground, or none (No backgrounds): the rows keep their own
-- fills, the words their outline. Painted as the world loads and as the
-- options change it (Options.lua, No backgrounds: every SurvivorUI_Grounds).
SurvivorUI_Grounds = SurvivorUI_Grounds or {}
function SurvivorUI_Grounds.build()
	list:SetBackdropColor(0.04, 0.04, 0.07, Bare("build") and 0 or 0.55)
	worn:SetBackdropColor(0.04, 0.04, 0.07, Bare("worn") and 0 or 0.55)
end

local function SaveWorn()
	local settings = Settings()
	settings.wornLeft = math.floor(worn:GetLeft() + 0.5)
	settings.wornTop = math.floor(worn:GetTop() + 0.5)
end

-- Where it was moved to; else under the build list, or in its place with the
-- list off. Looked at only as that changes.
local wornPlace

local function PlaceWorn()
	local settings = Settings()
	local place = settings.wornLeft and "moved" or list:IsShown() and "under" or "instead"
	if place == wornPlace then
		return
	end
	wornPlace = place
	worn:ClearAllPoints()
	if place == "moved" then
		worn:SetPoint("TOPLEFT", UIParent, "BOTTOMLEFT", settings.wornLeft, settings.wornTop)
	elseif place == "under" then
		worn:SetPoint("TOPLEFT", list, "BOTTOMLEFT", 0, 0)
	else
		worn:SetPoint("TOPLEFT", list, "TOPLEFT", 0, 0)
	end
end

-- The jewelry worn, the gear a run drops: one row a slot, filled with the
-- piece's quality color, the slot's name and what the piece gives in short,
-- or the piece's own name alone (the options' Build list tab); an empty slot
-- faint. Hover a piece for its own tooltip.
local gearLines = {}
for index = 1, table.getn(GEAR_SLOTS) do
	local line = CreateFrame("Frame", nil, worn)
	line:SetWidth(WIDTH)
	line:SetHeight(GEAR_ROW - 1)
	line:SetPoint("TOPLEFT", worn, "TOPLEFT", 6, -GEAR_TOP - (index - 1) * GEAR_ROW)

	line.wash = line:CreateTexture(nil, "BACKGROUND")
	line.wash:SetTexture(FLAT)
	line.wash:SetAllPoints(line)

	line.edges = {}
	for _, side in pairs({ "TOP", "BOTTOM", "LEFT", "RIGHT" }) do
		local edge = line:CreateTexture(nil, "BORDER")
		edge:SetTexture(FLAT)
		if side == "TOP" or side == "BOTTOM" then
			edge:SetHeight(1)
			edge:SetPoint(side.."LEFT", line, side.."LEFT", 0, 0)
			edge:SetPoint(side.."RIGHT", line, side.."RIGHT", 0, 0)
		else
			edge:SetWidth(1)
			edge:SetPoint("TOP"..side, line, "TOP"..side, 0, 0)
			edge:SetPoint("BOTTOM"..side, line, "BOTTOM"..side, 0, 0)
		end
		table.insert(line.edges, edge)
	end

	line.label = line:CreateFontString(nil, "OVERLAY")
	line.label:SetFont(SurvivorUI_FONT, 9 + FONT_BUMP, "OUTLINE")
	line.label:SetPoint("LEFT", line, "LEFT", 4, 0)
	line.tags = line:CreateFontString(nil, "OVERLAY")
	line.tags:SetFont(SurvivorUI_FONT, 9 + FONT_BUMP, "OUTLINE")
	line.tags:SetPoint("RIGHT", line, "RIGHT", -4, 0)

	line:EnableMouse(true)
	line:SetScript("OnEnter", function()
		if this.slot and GetInventoryItemLink("player", this.slot) then
			GameTooltip:SetOwner(this, "ANCHOR_LEFT")
			GameTooltip:SetInventoryItem("player", this.slot)
			GameTooltip:Show()
		elseif this.slot then
			local link, g = SurvivorUI_WornLink(this.slot)
			if g then
				local _, _, colored = string.find(link, "^(|c%x%x%x%x%x%x%x%x)")
				GameTooltip:SetOwner(this, "ANCHOR_LEFT")
				GameTooltip:SetText((colored or "")..tostring(g.name or g.bonus or "?").."|r")
				GameTooltip:AddLine((string.gsub(tostring(g.text or ""), " \194\183 ", "\n")), 1, 1, 1, 1)
				GameTooltip:Show()
			end
		end
	end)
	line:SetScript("OnLeave", function() GameTooltip:Hide() end)
	gearLines[index] = line
end

local function PaintGear(line, r, g, b, fill, edge)
	line.wash:SetVertexColor(r, g, b, fill)
	for _, piece in pairs(line.edges) do
		piece:SetVertexColor(r, g, b, edge)
	end
end

-- A piece's bonuses beside its slot, a point or two smaller when they would
-- run into it (a legendary amulet has many). Sized again only when the text
-- changes, as a font set over and over costs.
-- A legendary amulet's spell, short, to leave room for its bonuses: several
-- words by their initials ("Hammer of Justice" HoJ), one long word cut
-- ("Consecration" Consec.). Hover the row for the whole name.
local SMALL_WORDS = { of = true, the = true, ["and"] = true }

local function Short(spell)
	-- In a language the addon speaks: the game's name, its first characters.
	if SurvivorUI_Translated() then
		return SurvivorUI_Cut(SurvivorUI_Native(spell), 3)
	end
	local initials, words = "", 0
	for word in string.gfind(spell, "%S+") do
		words = words + 1
		local first = string.sub(word, 1, 1)
		initials = initials..(SMALL_WORDS[string.lower(word)] and string.lower(first) or string.upper(first))
	end
	if words > 1 then
		return initials
	end
	if string.len(spell) > 7 then
		return string.sub(spell, 1, 6).."."
	end
	return spell
end

-- Never over the slot's name and rank: a point or two smaller first, down
-- to 7; still too long (a legendary amulet's four or five), the first ones
-- and "...+" for the rest, which the piece's tooltip shows on hover. At the
-- piece's text size (the options, Jewelry worn), sized again as it or the
-- slot's words change.
local SEPARATOR = " \194\183 "

local function FitTags(line, text)
	-- No tags (a row by its name): nothing to fit, even when the name took
	-- the whole row (fitted, it would be " · ...+" over the name's end).
	if text == "" then
		line.tags:SetText("")
		line.tagText = nil
		return
	end
	local step = SurvivorUI_PieceTextStep and SurvivorUI_PieceTextStep("Jewelry worn") or 0
	-- The face too: one worn since (the language's, the piece's) measures anew.
	local face, labelSize = line.label:GetFont()
	face = face or SurvivorUI_FONT
	local key = (line.label:GetText() or "").."|"..text.."|"..step.."|"..math.floor((labelSize or 0) + 0.5).."|"..face
	if line.tagText == key then
		return
	end
	local labelWidth = line.label:GetStringWidth()
	-- A label not drawn yet measures nothing: sized again next time (none,
	-- the slot and rank both off, measures nothing too).
	line.tagText = (labelWidth > 0 or (line.label:GetText() or "") == "") and key or nil
	local room = WIDTH - 8 - labelWidth - 10
	-- Its size told to EditCard.lua's Dress as its own (base) and as the one
	-- it is at, so the text size is not added twice.
	local function Fits(size, words)
		local base = size + FONT_BUMP
		local want = math.max(6, base + step)
		line.tags:SetFont(face, want, "OUTLINE")
		line.tags.suiBase, line.tags.suiSize, line.tags.suiPath = base, want, line.tags:GetFont()
		line.tags:SetText(words)
		return line.tags:GetStringWidth() <= room
	end
	for size = 9, 7, -1 do
		if Fits(size, text) then
			return
		end
	end
	local parts, from = {}, 1
	while true do
		local at = string.find(text, SEPARATOR, from, true)
		if not at then
			table.insert(parts, string.sub(text, from))
			break
		end
		table.insert(parts, string.sub(text, from, at - 1))
		from = at + string.len(SEPARATOR)
	end
	for count = table.getn(parts) - 1, 1, -1 do
		local shown = {}
		for index = 1, count do
			shown[index] = parts[index]
		end
		if Fits(7, table.concat(shown, SEPARATOR)..SEPARATOR.."...+") then
			return
		end
	end
	Fits(6, parts[1]..SEPARATOR.."...+")
end

-- The slot's words (or a piece's name) at a size: the piece's text size step
-- on it, told to EditCard.lua's Dress as FitTags tells it. Its width.
local function LabelAt(line, points, words, path, flags, step)
	local base = points + FONT_BUMP
	local want = math.max(6, base + step)
	line.label:SetFont(path, want, flags)
	line.label.suiBase, line.label.suiSize, line.label.suiPath = base, want, line.label:GetFont()
	line.label:SetText(words)
	return line.label:GetStringWidth(), want
end

-- A piece by its name, fit to the row as the Jewelry Collection's names are
-- (Jewelry.lua's Fit; Lucas, 2026-11-04, a Russian name is long: "Безупречная
-- зачарованная водоросль южных морей"): at its size; else a point smaller,
-- never under 7; else cut at its size with "...", its rank kept after. Hover
-- the row for the piece's tooltip, its whole name the title. Measured again
-- only as the name, the face or the text size change (a size step put on
-- after it was cut ran it out of the panel); a name not drawn yet measures
-- nothing, and is fit on the next draw.
local function FitName(line, name)
	local step = SurvivorUI_PieceTextStep and SurvivorUI_PieceTextStep("Jewelry worn") or 0
	local path, _, flags = line.label:GetFont()
	path, flags = path or SurvivorUI_FONT, flags or "OUTLINE"
	local key = name.."|"..step.."|"..path
	if line.named == key then
		return
	end
	line.fitted = true
	local width, want = LabelAt(line, 9, name, path, flags, step)
	if width == 0 then
		line.named = nil
		return
	end
	line.named = key
	local room = WIDTH - 8
	if width <= room or (want > 7 and LabelAt(line, 8, name, path, flags, step) <= room) then
		return
	end
	LabelAt(line, 9, name, path, flags, step)
	local _, _, words, rank = string.find(name, "^(.-)( [IVXL]+%+?)$")
	line.label:SetText(CutTo(words or name, room, function(shown)
		line.label:SetText(shown)
		return line.label:GetStringWidth()
	end, rank))
end

-- The quality color a link carries: "|cffa335ee" is an epic's purple.
local function Quality(link)
	local _, _, rr, gg, bb = string.find(link, "|c%x%x(%x%x)(%x%x)(%x%x)")
	return (tonumber(rr or "cc", 16) or 204) / 255, (tonumber(gg or "cc", 16) or 204) / 255, (tonumber(bb or "cc", 16) or 204) / 255
end

-- How a row tells a piece (the options, Jewelry worn): by its stats, the slot
-- (a legendary amulet's spell, short, in its place) and the piece's rank as
-- a Roman numeral at the left, either or both, "Ring  II", and what it gives
-- at the right; or by its name alone, its rank on it or not. The words at the
-- left and at the right.
local function GearWords(label, piece, name)
	local db = Settings()
	if db.jewelryNames then
		name = SurvivorUI_Native(name or "?")
		if db.jewelryRank == false then
			name = string.gsub(name, " [IVXL]+%+?$", "")
		end
		return name, ""
	end
	local slot = db.jewelrySlot ~= false and (piece.spell and Short(piece.spell) or SurvivorUI_T(label)) or nil
	local rank = db.jewelryRank ~= false and piece.rank ~= "" and piece.rank or nil
	return slot and rank and (slot.."  "..rank) or slot or rank or "", piece.tags ~= "" and piece.tags or "-"
end

-- A row's words: a name cut to the row, or the left words and the right ones
-- beside them, a point or two smaller when long; the right ones at the row's
-- left when nothing is there (its slot and rank both off).
local function GearText(line, left, right, named)
	if named then
		FitName(line, left)
		FitTags(line, "")
	else
		line.named = nil
		-- Back at its own size from a name's fit (a point smaller).
		if line.fitted then
			line.fitted = nil
			local path, _, flags = line.label:GetFont()
			LabelAt(line, 9, left, path or SurvivorUI_FONT, flags or "OUTLINE",
				SurvivorUI_PieceTextStep and SurvivorUI_PieceTextStep("Jewelry worn") or 0)
		end
		line.label:SetText(left)
		FitTags(line, right)
	end
	local alone = left == ""
	if line.alone ~= alone then
		line.alone = alone
		line.tags:ClearAllPoints()
		if alone then
			line.tags:SetPoint("LEFT", line, "LEFT", 4, 0)
		else
			line.tags:SetPoint("RIGHT", line, "RIGHT", -4, 0)
		end
	end
end

-- A row in its place among those shown (the empty slots may be left out: the
-- options, Jewelry worn), set only as it changes.
local function PlaceGear(line, place)
	if line.place ~= place then
		line.place = place
		line:ClearAllPoints()
		line:SetPoint("TOPLEFT", worn, "TOPLEFT", 6, -GEAR_TOP - (place - 1) * GEAR_ROW)
	end
end

local function DrawGear()
	worn.title:SetText(SurvivorUI_T("Jewelry"))
	local db = Settings()
	local paint = GEAR_PAINT[db.jewelryColor or "row"] or GEAR_PAINT.row
	local shown = 0
	for index = 1, table.getn(GEAR_SLOTS) do
		local slot, label = GEAR_SLOTS[index][1], GEAR_SLOTS[index][2]
		local line = gearLines[index]
		line.slot = slot
		local link = SurvivorUI_WornLink(slot)
		if link or db.jewelryEmpty ~= false then
			shown = shown + 1
			PlaceGear(line, shown)
		end
		if link then
			local r, g, b = Quality(link)
			if db.jewelryNames then
				local _, _, name = string.find(link, "%[(.-)%]")
				GearText(line, GearWords(label, nil, name), "", true)
			else
				local left, right = GearWords(label, ReadPiece(slot, link))
				GearText(line, left, right)
			end
			if paint.plain then
				PaintGear(line, PLAIN[1], PLAIN[2], PLAIN[3], paint.fill, paint.edge)
			else
				PaintGear(line, r, g, b, paint.fill, paint.edge)
			end
			if not paint.words then
				r, g, b = 1, 1, 1
			end
			line.label:SetTextColor(r, g, b)
			line.tags:SetTextColor(r, g, b)
			line:Show()
		elseif db.jewelryEmpty ~= false then
			PaintGear(line, PLAIN[1], PLAIN[2], PLAIN[3], GEAR_PAINT.empty.fill, GEAR_PAINT.empty.edge)
			GearText(line, SurvivorUI_T(label), SurvivorUI_T("empty"))
			line.label:SetTextColor(0.45, 0.45, 0.5)
			line.tags:SetTextColor(0.4, 0.4, 0.45)
			line:Show()
		else
			line:Hide()
		end
	end
	-- As tall as the rows shown; with none, its title alone.
	local tall = GEAR_TOP + shown * GEAR_ROW + 5
	if worn.tall ~= tall then
		worn.tall = tall
		worn:SetHeight(tall)
	end
end

-- For the options' preview (Jewelry worn tab): the rows as the panel shows
-- them now, by the settings, one a slot shown: { left, right, color, empty,
-- named }; the run's when in one with a piece worn, else a sample: a piece of
-- each rarity, legendary to uncommon, with its codex bonus (JewelryData.lua),
-- and an empty slot. And whether they are the run's.
function SurvivorUI_WornRows()
	local db = Settings()
	local real = false
	for index = 1, table.getn(GEAR_SLOTS) do
		real = real or (Running() and SurvivorUI_WornLink(GEAR_SLOTS[index][1]) and true)
	end
	-- By slot: its name, rank, quality and rarity (a ring's or a trinket's
	-- bonus, Common 1 to Legendary 5; an amulet has its own).
	local sample = {
		{ "Onyxia Tooth Pendant", "III", "ff8000" },
		{ "Band of Accuria", "IV", "a335ee", 4 },
		{ "Quick Strike Ring", "II", "0070dd", 3 },
		{ "Carrot on a Stick", "V", "1eff00", 2 },
	}
	local rows = {}
	for index = 1, table.getn(GEAR_SLOTS) do
		local slot, label = GEAR_SLOTS[index][1], GEAR_SLOTS[index][2]
		local link, each = nil, sample[index]
		if real then
			link = SurvivorUI_WornLink(slot)
		elseif each then
			link = "|cff"..each[3].."|Hitem:0|h["..SurvivorUI_Native(each[1]).." "..each[2].."]|h|r"
		end
		if link then
			local left, right
			if db.jewelryNames then
				local _, _, name = string.find(link, "%[(.-)%]")
				left, right = GearWords(label, nil, name)
			elseif real then
				left, right = GearWords(label, ReadPiece(slot, link))
			else
				local lines, given = {}, {}
				for _, entry in pairs(SurvivorUI_JEWELRY and SurvivorUI_JEWELRY[label] or {}) do
					if type(entry) == "table" and entry[1] == each[1] then
						given = label == "Neck" and entry[3] or { entry[2][each[4]] }
					end
				end
				for line = 1, table.getn(given) do
					lines[line] = string.lower(given[line])
				end
				left, right = GearWords(label, { rank = each[2], tags = TagsOf(lines) })
			end
			table.insert(rows, { left = left, right = right, color = { Quality(link) }, named = db.jewelryNames })
		elseif db.jewelryEmpty ~= false then
			table.insert(rows, { left = SurvivorUI_T(label), right = SurvivorUI_T("empty"), empty = true })
		end
	end
	return rows, real
end

local elapsed = 0
local watcher = CreateFrame("Frame")
watcher:SetScript("OnUpdate", function()
	elapsed = elapsed + arg1
	-- A lasting spell's timer counts down in tenths.
	if elapsed < (timing and 0.1 or 0.25) then
		return
	end
	elapsed = 0
	if Settings().buildList and Running() then
		Draw()
		if not list:IsShown() then
			list:Show()
		end
	elseif list:IsShown() then
		list:Hide()
	end
	if Settings().jewelryWorn ~= false and Running() then
		PlaceWorn()
		DrawGear()
		if not worn:IsShown() then
			worn:Show()
		end
	elseif worn:IsShown() then
		worn:Hide()
	end
end)

-- The game's own build, its row of spells and jewelry with their cooldowns:
-- away while this list is on, unless asked to stay (gameBuildToo: since the
-- game's 0.111 its talent icon is the only place that counts down to the
-- next Felguard or Dread Lord of Butcher and Pact of the Nathrezim). The
-- setting is the game's and is saved, so the addon remembers that it was the
-- one to turn it off.
local function ApplyGameHud()
	if not (AZS_SetHudShown and AZS_IsHudShown) then
		return
	end
	local settings = Settings()
	if (settings.buildList and not settings.gameBuildToo) or settings.noGameBuild then
		if AZS_IsHudShown("build") then
			AZS_SetHudShown("build", false)
			settings.hidGameBuild = true
		end
	elseif settings.hidGameBuild then
		AZS_SetHudShown("build", true)
		settings.hidGameBuild = nil
	end
end

-- For the options: off, the Default one, or nothing ("When off").
SurvivorUI_GameHud = SurvivorUI_GameHud or {}
SurvivorUI_GameHud.build = ApplyGameHud

-- For the last runs (RunHistory.lua): the build as it stands, the spells by
-- rank, the highest first, then the racial: { name, rank, icon, color, racial,
-- range, cd }, the range and the cooldown as the list shows them.
function SurvivorUI_BuildSnapshot()
	local spells = AZS_SPELLS or {}
	local count = table.getn(spells)
	local order = {}
	for index = 1, math.max(0, count - 1) do
		table.insert(order, index)
	end
	table.sort(order, function(a, b)
		local ra = tonumber(Field(spells[a], "rank", 3)) or 0
		local rb = tonumber(Field(spells[b], "rank", 3)) or 0
		if ra ~= rb then
			return ra > rb
		end
		return a < b
	end)
	local list = {}
	local showRange, showCooldown = Shows()
	local function Add(entry, slot, racial)
		local name = SpellName(Field(entry, "key", 1))
		local color = SurvivorUI_MeterColor and SurvivorUI_MeterColor(name) or { 0.8, 0.8, 0.8 }
		local rank = tonumber(Field(entry, "rank", 3))
		table.insert(list, {
			name = name, rank = rank, racial = racial,
			icon = GetActionTexture and GetActionTexture(slot) or nil,
			color = { color[1], color[2], color[3] },
			range = showRange and (Reach(slot, name, rank) or "") or nil,
			cd = showCooldown and CooldownText(entry) or nil,
		})
	end
	for index = 1, table.getn(order) do
		Add(spells[order[index]], Slot(order[index], count), false)
	end
	if count >= 1 then
		Add(spells[count], Slot(count, count), true)
	end
	return list
end

-- For the range rings (WorldMarks.lua): the longest reach among the build's
-- spells that strike, in yards, and that spell's name, read off the buttons'
-- tooltips as the list's Info is (a radius, for one with no range). Heals,
-- shields and lasting buffs left out, and the racial. Read again every two
-- seconds, or as the game sends its list anew, or as the class's spell
-- changes (the options, Spell per class, Lucas 2026-11-04): that spell's
-- reach wins while it is in the build, the longest till then. The third
-- answer says which: "chosen" (the class's spell), "missing" (one chosen,
-- not in the build yet: the longest), nil (none chosen: the longest).
local longest = { at = -10 }

-- The class's spell, by its key in AZS_SPELLS ("execute"), or nil for the
-- longest; one for every hero of that class (SurvivorUIDB is the account's).
-- The hero's class unless given; the class second.
function SurvivorUI_RangeSpell(class)
	if not class then
		local _
		_, class = UnitClass("player")
	end
	local chosen = SurvivorUIDB and SurvivorUIDB.rangeSpells
	return class and chosen and chosen[class] or nil, class
end

-- key nil: back to the longest; the rings follow at once.
function SurvivorUI_SetRangeSpell(class, key)
	local db = Settings()
	db.rangeSpells = db.rangeSpells or {}
	db.rangeSpells[class] = key
	if not next(db.rangeSpells) then
		db.rangeSpells = nil
	end
	longest.at = -10
end

-- Whether the build holds this spell (the racial left out), and its reach
-- now, in yards, read off its button's tooltip.
function SurvivorUI_SpellReach(key)
	local spells = AZS_SPELLS or {}
	local count = table.getn(spells)
	for index = 1, count - 1 do
		local entry = spells[index]
		if Field(entry, "key", 1) == key then
			local reach = Reach(Slot(index, count), SpellName(key), Field(entry, "rank", 3))
			return true, reach and tonumber((string.gsub(reach, " yd$", "")))
		end
	end
	return false
end

function SurvivorUI_LongestReach()
	local choice = SurvivorUI_RangeSpell()
	if GetTime() - longest.at < 2 and longest.seen == AZS_SPELLS_UPDATED and longest.choice == choice then
		return longest.yards, longest.name, longest.why
	end
	longest.at, longest.seen, longest.choice = GetTime(), AZS_SPELLS_UPDATED, choice
	longest.yards, longest.name, longest.why = nil, nil, choice and "missing" or nil
	local spells = AZS_SPELLS or {}
	local count = table.getn(spells)
	local chosenYards, chosenName
	for index = 1, count - 1 do
		local entry = spells[index]
		local key = Field(entry, "key", 1)
		if key and key == choice then
			-- Held: no longer missing, though its reach may not read.
			longest.why = nil
		end
		if key and not (LASTING[key] or HEALING[key] or ABSORBING[key]) then
			local name = SpellName(key)
			local reach = Reach(Slot(index, count), name, Field(entry, "rank", 3))
			local yards = reach and tonumber((string.gsub(reach, " yd$", "")))
			if yards and key == choice then
				chosenYards, chosenName = yards, name
			end
			if yards and yards > (longest.yards or 0) then
				longest.yards, longest.name = yards, name
			end
		end
	end
	if chosenYards then
		longest.yards, longest.name, longest.why = chosenYards, chosenName, "chosen"
	end
	return longest.yards, longest.name, longest.why
end

-- For the options' preview (Build list tab): the columns for these choices
-- and the name's room, as the list lays them out (the symbol and the rank
-- shown unless false; the rank column a number's wide unless given), and
-- what each row shows as chosen: Info, the cooldown, Info's symbol, the rank.
function SurvivorUI_BuildLayout(showRange, showCooldown, showSymbol, showRank, rankRoom)
	return Layout(showRange, showCooldown, showSymbol ~= false, showRank ~= false, rankRoom)
end

function SurvivorUI_BuildShows()
	return Shows()
end

-- And the rows as the list draws them now: the spells from the highest rank
-- down, the empty slots, then the racial. Each { name (as shown), spell and
-- tag (the name and the racial's "(racial)" apart, for their fit), rank, icon,
-- color, racial, empty, symbol (an Art file), tint, number, numberColor (none:
-- the row's own), cd, share (a lasting spell's time left, for its timer) };
-- nil out of a run.
function SurvivorUI_BuildRows()
	if not Running() then
		return nil
	end
	local spells = AZS_SPELLS
	local count = table.getn(spells)
	local order = RankOrder(spells, math.max(0, count - 1))
	local showRange, showCooldown = Shows()
	local shown = {}
	local function Add(entry, actionSlot, racial)
		local key = Field(entry, "key", 1)
		local name = SpellName(key)
		local native = SurvivorUI_Native(name)
		local row = {
			name = racial and native.."  |cff8a8a8a"..SurvivorUI_T("(racial)").."|r" or native,
			spell = native, tag = racial and SurvivorUI_T("(racial)") or nil,
			rank = tonumber(Field(entry, "rank", 3)) or "", racial = racial,
			icon = GetActionTexture and GetActionTexture(actionSlot) or nil,
			color = SurvivorUI_MeterColor and SurvivorUI_MeterColor(name) or { 0.8, 0.8, 0.8 },
			cd = showCooldown and CooldownText(entry) or "",
		}
		local lasting
		lasting, row.symbol, row.tint, row.number, row.numberColor = InfoOf(entry, key, actionSlot, name, racial, showRange)
		if lasting then
			row.number, row.numberColor, row.share = LastingCell(entry, key, actionSlot, name, showRange)
		end
		table.insert(shown, row)
	end
	for place = 1, SLOTS do
		if order[place] then
			Add(spells[order[place]], Slot(order[place], count), false)
		else
			table.insert(shown, { empty = true, name = SurvivorUI_T("empty slot") })
		end
	end
	if count >= 1 then
		Add(spells[count], Slot(count, count), true)
	end
	return shown
end

-- And the list's fits on the preview's own words: a name's (FitSpell's: its
-- size, 9 or 8, nil while it measures nothing, and its words; Width(points,
-- words) their width at that size in the list's measures, step the text size
-- step), the cooldowns' (FitCooldown's: the size they all go at, and each as
-- its cell shows it, measured by Width the same way), and a cooldown of so
-- many seconds as the list writes it (its sample's).
function SurvivorUI_FitBuildName(name, tag, room, step, Width)
	return FitChoice(name, tag, room, step, Width)
end

function SurvivorUI_FitCooldowns(texts, width, Width)
	local step = 1
	if SurvivorUI_Language and SurvivorUI_Language() then
		for index = 1, table.getn(texts) do
			if texts[index] ~= "" then
				step = math.max(step, StepOf(texts[index], width, Width))
			end
		end
	end
	local shown = {}
	for index = 1, table.getn(texts) do
		shown[index] = CD_STEPS[step][2] and Spaceless(texts[index]) or texts[index]
	end
	return CD_STEPS[step][1], shown
end

function SurvivorUI_CooldownText(seconds)
	return CooldownText({ cdmax = seconds })
end

-- For the last runs too: the jewelry lines as they read, one a slot: { label,
-- tags, color, item, name, tip }, or { label, empty } for a slot with nothing.
function SurvivorUI_GearSnapshot()
	local gear = {}
	for index = 1, table.getn(GEAR_SLOTS) do
		local slot, label = GEAR_SLOTS[index][1], GEAR_SLOTS[index][2]
		local link = SurvivorUI_WornLink(slot)
		if link then
			local _, _, rr, gg, bb = string.find(link, "|c%x%x(%x%x)(%x%x)(%x%x)")
			local _, _, item = string.find(link, "|H(item:[%d:%-]+)|h")
			local _, _, name = string.find(link, "%[(.-)%]")
			local piece = ReadPiece(slot, link)
			-- Its tooltip as it reads now.
			local tip
			if SurvivorUI_ReadTooltip then
				scan:SetOwner(WorldFrame, "ANCHOR_NONE")
				scan:ClearLines()
				scan:SetInventoryItem("player", slot)
				tip = SurvivorUI_ReadTooltip(scan)
				scan:Hide()
			end
			table.insert(gear, {
				label = (piece.spell and Short(piece.spell) or label)..(piece.rank ~= "" and ("  "..piece.rank) or ""),
				tags = piece.tags ~= "" and piece.tags or "-",
				color = { (tonumber(rr or "cc", 16) or 204) / 255, (tonumber(gg or "cc", 16) or 204) / 255, (tonumber(bb or "cc", 16) or 204) / 255 },
				item = item, name = name, tip = tip,
				icon = SurvivorUI_WornIcon(slot),
			})
		else
			table.insert(gear, { label = label, empty = true })
		end
	end
	return gear
end

-- The armor and the weapons worn, for the last runs too: they stay as they
-- are through a run. One a piece worn, in the order of the character pane:
-- { slot, icon, color, item, name, tip }; and the set they make, as their
-- tooltips say it ("Field Marshal's (8/8)"): { name, count, of }, or nil.
local ARMOR_SLOTS = { 1, 3, 15, 5, 9, 10, 6, 7, 8, 16, 17, 18 }
function SurvivorUI_ArmorSnapshot()
	local armor, set = {}, nil
	if not GetInventoryItemLink then
		return armor
	end
	for index = 1, table.getn(ARMOR_SLOTS) do
		local slot = ARMOR_SLOTS[index]
		local link = GetInventoryItemLink("player", slot)
		local _, _, item = string.find(link or "", "|H(item:[%d:%-]+)|h")
		if item then
			local _, _, rr, gg, bb = string.find(link, "|c%x%x(%x%x)(%x%x)(%x%x)")
			local _, _, name = string.find(link, "%[(.-)%]")
			local tip
			if SurvivorUI_ReadTooltip then
				scan:SetOwner(WorldFrame, "ANCHOR_NONE")
				scan:ClearLines()
				scan:SetInventoryItem("player", slot)
				tip = SurvivorUI_ReadTooltip(scan)
				scan:Hide()
			end
			for _, line in pairs(slot < 16 and tip or {}) do
				local _, _, setName, count, of = string.find(line.l or "", "^(.-) ?%((%d+)/(%d+)%)$")
				if setName and setName ~= "" and not (set and set.count >= tonumber(count)) then
					set = { name = setName, count = tonumber(count), of = tonumber(of) }
				end
			end
			table.insert(armor, {
				slot = slot, item = item, name = name, tip = tip,
				icon = GetInventoryItemTexture and GetInventoryItemTexture("player", slot) or nil,
				color = { (tonumber(rr or "ff", 16) or 255) / 255, (tonumber(gg or "ff", 16) or 255) / 255, (tonumber(bb or "ff", 16) or 255) / 255 },
			})
		end
	end
	return armor, set
end

function SurvivorUI_ToggleWorn()
	local settings = Settings()
	settings.jewelryWorn = settings.jewelryWorn == false
end

function SurvivorUI_ToggleBuild()
	local settings = Settings()
	settings.buildList = not settings.buildList
	ApplyGameHud()
	DEFAULT_CHAT_FRAME:AddMessage("Survivor UI: "..(settings.buildList
		and (settings.gameBuildToo and "build list shown, and the Default row of spells stays with it."
			or "build list shown; the Default row of spells is put away.")
		or (settings.noGameBuild and "build list hidden, and the Default row of spells stays away." or "build list hidden; the Default row of spells is back.")))
end

local loader = CreateFrame("Frame")
loader:RegisterEvent("PLAYER_ENTERING_WORLD")
loader:SetScript("OnEvent", function()
	RestorePlace()
	wornPlace = nil
	PlaceWorn()
	ApplyGameHud()
end)

if SurvivorUI_RegisterMover then
	SurvivorUI_RegisterMover(list, "Build list", SavePlace, nil, RestorePlace)
	SurvivorUI_RegisterMover(worn, "Jewelry worn", function()
		SaveWorn()
		wornPlace = "moved"
	end, nil, function()
		wornPlace = nil
		PlaceWorn()
	end)
end
